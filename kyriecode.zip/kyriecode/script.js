document.addEventListener('DOMContentLoaded', function () {
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');

    tabs.forEach((tab, index) => {
        tab.addEventListener('click', () => {
            tabContents.forEach(content => {
                content.style.display = 'none';
            });

            tabContents[index].style.display = 'block';
        });
    });

    
    tabContents[0].style.display = 'block';
});